# test_bot.py
import sys
import os

# Добавляем текущую директорию в путь для импорта
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from questions import questions
from stats import save_result, get_stats

def test_questions():
    """Тестирует структуру вопросов"""
    print("🧪 Тестирование вопросов...")
    
    assert len(questions) == 10, f"Ожидалось 10 вопросов, получено {len(questions)}"
    
    for i, q in enumerate(questions):
        assert "question" in q, f"Вопрос {i}: отсутствует поле 'question'"
        assert "options" in q, f"Вопрос {i}: отсутствует поле 'options'"
        assert "answer" in q, f"Вопрос {i}: отсутствует поле 'answer'"
        assert len(q["options"]) == 3, f"Вопрос {i}: должно быть 3 варианта ответа"
        assert q["answer"] in q["options"], f"Вопрос {i}: правильный ответ должен быть в вариантах"
    
    print("✅ Все вопросы корректны!")

def test_stats():
    """Тестирует систему статистики"""
    print("📊 Тестирование статистики...")
    
    # Тестируем сохранение результата
    test_user_id = 12345
    test_username = "test_user"
    test_score = 8
    
    save_result(test_user_id, test_username, test_score)
    
    # Получаем статистику
    results = get_stats()
    
    assert str(test_user_id) in results, "Результат не был сохранен"
    assert results[str(test_user_id)]["name"] == test_username, "Имя пользователя не совпадает"
    assert results[str(test_user_id)]["score"] == test_score, "Балл не совпадает"
    
    print("✅ Система статистики работает корректно!")

def test_quiz_logic():
    """Тестирует логику викторины"""
    print("🎯 Тестирование логики викторины...")
    
    # Проверяем, что все вопросы имеют уникальные ответы
    all_answers = []
    for q in questions:
        all_answers.extend(q["options"])
    
    # Проверяем, что нет дублирующихся вопросов
    question_texts = [q["question"] for q in questions]
    assert len(question_texts) == len(set(question_texts)), "Есть дублирующиеся вопросы"
    
    print("✅ Логика викторины корректна!")

def main():
    """Запускает все тесты"""
    print("🚀 Запуск тестов Quiz Bot...\n")
    
    try:
        test_questions()
        test_stats()
        test_quiz_logic()
        
        print("\n🎉 Все тесты пройдены успешно!")
        print("✅ Бот готов к работе!")
        
    except Exception as e:
        print(f"\n❌ Ошибка в тестах: {e}")
        return False
    
    return True

if __name__ == "__main__":
    main()

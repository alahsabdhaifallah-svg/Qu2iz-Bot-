#!/usr/bin/env python3
# handlers.py
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from questions import questions
from stats import save_result, get_stats

# Словарь для хранения текущих вопросов пользователей
user_questions = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    user = update.effective_user
    welcome_text = (
        f"Привет, {user.first_name}! 👋\n\n"
        "Добро пожаловать в Quiz Bot! 🧠\n\n"
        "Я задам тебе 10 вопросов. Выбирай правильный ответ из предложенных вариантов.\n\n"
        "Готов начать? Нажми кнопку ниже!"
    )

    keyboard = [[InlineKeyboardButton("Начать викторину! 🚀", callback_data="start_quiz")]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    if update.message:
        await update.message.reply_text(welcome_text, reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик нажатий на кнопки"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    username = query.from_user.username or query.from_user.first_name

    if query.data == "start_quiz":
        await start_quiz(query, user_id, username)
    elif query.data.startswith("answer_"):
        await handle_answer(query, user_id)
    elif query.data == "next_question":
        await show_question(query, user_id)
    elif query.data == "restart":
        await start_quiz(query, user_id, username)

async def start_quiz(query, user_id: int, username: str):
    """Начинает викторину для пользователя"""
    quiz_questions = questions.copy()
    random.shuffle(quiz_questions)

    user_questions[user_id] = {
        "questions": quiz_questions,
        "current_question": 0,
        "score": 0,
        "username": username,
    }

    await show_question(query, user_id)

async def show_question(query, user_id: int):
    """Показывает текущий вопрос пользователю"""
    user_data = user_questions.get(user_id)
    if not user_data:
        return

    current_q = user_data["current_question"]
    if current_q >= len(user_data["questions"]):
        await finish_quiz(query, user_id)
        return

    question_data = user_data["questions"][current_q]
    question_text = (
        f"Вопрос {current_q + 1} из {len(user_data['questions'])}:\n\n{question_data['question']}"
    )

    keyboard = [
        [InlineKeyboardButton(option, callback_data=f"answer_{current_q}_{i}")]
        for i, option in enumerate(question_data["options"])
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    if query.message:
        await query.message.edit_text(question_text, reply_markup=reply_markup)

async def handle_answer(query, user_id: int):
    """Обрабатывает ответ пользователя"""
    user_data = user_questions.get(user_id)
    if not user_data:
        if query.message:
            await query.message.reply_text("Начните викторину заново командой /start")
        return

    current_q = user_data["current_question"]
    if current_q >= len(user_data["questions"]):
        return

    parts = query.data.split("_")
    question_index = int(parts[1])
    answer_index = int(parts[2])

    question_data = user_data["questions"][question_index]
    selected_answer = question_data["options"][answer_index]
    correct_answer = question_data["answer"]

    is_correct = selected_answer == correct_answer
    if is_correct:
        user_data["score"] += 1
        result_text = (
            f"✅ Правильно! +1 балл\n\nВаш ответ: {selected_answer}\nПравильный ответ: {correct_answer}"
        )
    else:
        result_text = (
            f"❌ Неправильно!\n\nВаш ответ: {selected_answer}\nПравильный ответ: {correct_answer}"
        )

    user_data["current_question"] += 1

    if user_data["current_question"] < len(user_data["questions"]):
        keyboard = [[InlineKeyboardButton("Следующий вопрос ➡️", callback_data="next_question")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        if query.message:
            await query.message.edit_text(result_text, reply_markup=reply_markup)
    else:
        await finish_quiz(query, user_id)

async def finish_quiz(query, user_id: int):
    """Завершает викторину и показывает результаты"""
    user_data = user_questions.get(user_id)
    if not user_data:
        return

    score = user_data["score"]
    total_questions = len(user_data["questions"])
    username = user_data["username"]

    save_result(user_id, username, score)

    percentage = (score / total_questions) * 100
    if percentage == 100:
        result_text = "🎉 Отлично! Ты ответил на все вопросы правильно!"
    elif percentage >= 80:
        result_text = "👏 Отличный результат! Ты хорошо знаешь материал!"
    elif percentage >= 60:
        result_text = "👍 Хорошо! Есть куда расти."
    elif percentage >= 40:
        result_text = "😊 Неплохо! Попробуй еще раз."
    else:
        result_text = "🤔 Попробуй еще раз, чтобы улучшить результат!"

    final_text = (
        f"🏁 Викторина завершена!\n\n{result_text}\n\nВаш результат: {score}/{total_questions}"
        f" ({percentage:.1f}%)\n\nИспользуйте /stats чтобы посмотреть статистику всех участников."
    )

    keyboard = [[InlineKeyboardButton("Пройти еще раз 🔄", callback_data="restart")]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    if query.message:
        await query.message.edit_text(final_text, reply_markup=reply_markup)

    user_questions.pop(user_id, None)

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает статистику всех участников"""
    results = get_stats()
    if not results:
        if update.message:
            await update.message.reply_text("Пока нет результатов. Будьте первым! 🥇")
        return

    sorted_results = sorted(results.items(), key=lambda x: x[1]["score"], reverse=True)
    stats_lines = []
    for i, (_, data) in enumerate(sorted_results[:10]):
        medal = "🥇" if i == 0 else "🥈" if i == 1 else "🥉" if i == 2 else f"{i+1}."
        stats_lines.append(f"{medal} {data['name']}: {data['score']} баллов")

    stats_text = "📊 Статистика участников:\n\n" + "\n".join(stats_lines)
    if len(sorted_results) > 10:
        stats_text += f"\n\n... и еще {len(sorted_results) - 10} участников"

    if update.message:
        await update.message.reply_text(stats_text)

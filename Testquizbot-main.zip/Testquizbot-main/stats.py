# stats.py
import json
import os

RESULTS_FILE = "results.json"

if os.path.exists(RESULTS_FILE):
    with open(RESULTS_FILE, "r", encoding="utf-8") as f:
        results = json.load(f)
else:
    results = {}  # ключ: user_id, значение: {"name": str, "score": int}


def save_result(user_id, username, score):
    results[str(user_id)] = {"name": username, "score": score}
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=4)


def get_stats():
    return results
